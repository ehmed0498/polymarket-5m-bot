from __future__ import annotations
import time
from datetime import datetime, timezone
from config import Config
from market_scanner import MarketScanner
from strategy import ArbitrageStrategy
from paper_engine import PaperEngine

def main():
    cfg = Config()

    if cfg.live_trading:
        print("LIVE_TRADING=true detected.")
        print("This build intentionally refuses to place live orders.")
        print("Set LIVE_TRADING=false for paper testing.")
        return

    scanner = MarketScanner(cfg.gamma_url, cfg.clob_url, cfg.coins)
    strategy = ArbitrageStrategy(
        cfg.allocation_pct, cfg.min_edge_pct,
        cfg.estimated_fee_pct, cfg.estimated_slippage_pct
    )
    engine = PaperEngine(cfg.starting_balance)

    print("=" * 72)
    print("POLYMARKET 5-MINUTE CRYPTO ARBITRAGE BOT")
    print("MODE: PAPER")
    print(f"Starting balance: ${engine.balance:.2f}")
    print(f"Allocation: {cfg.allocation_pct*100:.2f}%")
    print(f"Minimum net edge: {cfg.min_edge_pct:.2f}%")
    print("=" * 72)

    while True:
        try:
            markets = scanner.find_5m_crypto_markets()
            print(f"\n[{datetime.now(timezone.utc).strftime('%H:%M:%S')} UTC] markets={len(markets)} balance=${engine.balance:.2f}")

            for market in markets:
                try:
                    quote = scanner.quote_pair(market)
                    if not quote:
                        continue
                    opp = strategy.evaluate(quote, engine.balance)
                    if opp:
                        print(
                            f"EDGE {opp.coin}: YES={opp.yes_price:.4f} "
                            f"NO={opp.no_price:.4f} pair={opp.pair_cost:.4f} "
                            f"net={opp.net_edge_pct:.3f}% budget=${opp.budget:.2f}"
                        )
                        result = engine.execute(opp)
                        print(
                            f"  PAPER FILLED: pairs={result['pairs']:.4f} "
                            f"profit=${result['profit']:.4f} balance=${result['balance']:.4f}"
                        )
                except Exception as e:
                    print(f"market error: {e}")

            time.sleep(cfg.poll_seconds)

        except KeyboardInterrupt:
            print("\nStopped.")
            print(f"Final balance: ${engine.balance:.2f}")
            print(f"Return: {engine.return_pct:.2f}%")
            break
        except Exception as e:
            print(f"scanner error: {e}")
            time.sleep(max(cfg.poll_seconds, 3))

if __name__ == "__main__":
    main()
