from __future__ import annotations
import json
import re
import time
from datetime import datetime, timezone
from typing import Any
import requests

def parse_jsonish(value: Any) -> Any:
    if isinstance(value, (list, dict)):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return value
    return value

def to_dt(value: Any):
    if not value:
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    s = str(value).strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
        return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).astimezone(timezone.utc)
    except Exception:
        return None

class MarketScanner:
    def __init__(self, gamma_url: str, clob_url: str, coins: tuple[str, ...]):
        self.gamma_url = gamma_url.rstrip("/")
        self.clob_url = clob_url.rstrip("/")
        self.coins = coins
        self.session = requests.Session()
        # Use browser-like headers because the Gamma API may reject the
        # custom/default GitHub Actions User-Agent with HTTP 403.
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/131.0 Safari/537.36"
            ),
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://polymarket.com/",
            "Origin": "https://polymarket.com",
        })

    def fetch_markets(self, limit=500):
        r = self.session.get(
            f"{self.gamma_url}/markets",
            params={"active": "true", "closed": "false", "limit": limit},
            timeout=10,
        )
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict):
            data = data.get("data", data.get("markets", []))
        return data if isinstance(data, list) else []

    def find_5m_crypto_markets(self):
        now = datetime.now(timezone.utc)
        result = []
        for m in self.fetch_markets():
            text = " ".join(str(m.get(k, "")) for k in ("question", "title", "slug", "description")).upper()
            coin = next((c for c in self.coins if re.search(rf"\b{re.escape(c)}\b", text)), None)
            if not coin:
                continue

            outcomes = parse_jsonish(m.get("outcomes"))
            token_ids = parse_jsonish(m.get("clobTokenIds") or m.get("clob_token_ids") or m.get("tokens"))
            if not isinstance(outcomes, list) or len(outcomes) < 2:
                continue
            if not isinstance(token_ids, list) or len(token_ids) < 2:
                continue

            end = to_dt(m.get("endDate") or m.get("end_date") or m.get("endTime"))
            if not end:
                continue

            seconds_left = (end - now).total_seconds()
            if not (-30 <= seconds_left <= 420):
                continue

            yes_idx = next((i for i, x in enumerate(outcomes) if str(x).lower() in {"yes", "up"}), 0)
            no_idx = next((i for i, x in enumerate(outcomes) if str(x).lower() in {"no", "down"}), 1)

            result.append({
                "id": str(m.get("id") or m.get("conditionId") or m.get("condition_id") or ""),
                "question": str(m.get("question") or m.get("title") or ""),
                "slug": str(m.get("slug") or ""),
                "coin": coin,
                "end": end,
                "seconds_left": seconds_left,
                "yes_token": str(token_ids[yes_idx]),
                "no_token": str(token_ids[no_idx]),
                "raw": m,
            })
        return result

    def get_book(self, token_id: str):
        r = self.session.get(
            f"{self.clob_url}/book",
            params={"token_id": token_id},
            timeout=5,
        )
        r.raise_for_status()
        return r.json()

    @staticmethod
    def best_ask(book):
        asks = book.get("asks") or []
        prices = []
        for x in asks:
            try:
                prices.append(float(x["price"]))
            except Exception:
                pass
        return min(prices) if prices else None

    @staticmethod
    def ask_size_at(book, price):
        total = 0.0
        for x in book.get("asks") or []:
            try:
                if abs(float(x["price"]) - price) < 1e-9:
                    total += float(x["size"])
            except Exception:
                pass
        return total

    def quote_pair(self, market):
        yes_book = self.get_book(market["yes_token"])
        no_book = self.get_book(market["no_token"])
        yes_ask = self.best_ask(yes_book)
        no_ask = self.best_ask(no_book)
        if yes_ask is None or no_ask is None:
            return None
        return {
            **market,
            "yes_ask": yes_ask,
            "no_ask": no_ask,
            "yes_ask_size": self.ask_size_at(yes_book, yes_ask),
            "no_ask_size": self.ask_size_at(no_book, no_ask),
            "pair_cost": yes_ask + no_ask,
            "timestamp": time.time(),
        }
