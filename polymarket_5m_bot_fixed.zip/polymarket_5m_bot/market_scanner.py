from __future__ import annotations
import json
import re
import time
from datetime import datetime, timezone
from typing import Any
import requests

def parse_jsonish(value: Any) -> Any:
    if isinstance(value, (list, dict)):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return value
    return value

def to_dt(value: Any):
    if not value:
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    s = str(value).strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
        return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).astimezone(timezone.utc)
    except Exception:
        return None

class MarketScanner:
    def __init__(self, gamma_url: str, clob_url: str, coins: tuple[str, ...]):
        self.gamma_url = gamma_url.rstrip("/")
        self.clob_url = clob_url.rstrip("/")
        self.coins = coins
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "polymarket-5m-paper-bot/1.0"})

    def fetch_markets(self, limit=500):
        # Legacy /markets is a broad flat feed and can omit the recurring
        # 5-minute crypto series. Keep this method for compatibility.
        r = self.session.get(
            f"{self.gamma_url}/markets",
            params={"active": "true", "closed": "false", "limit": min(limit, 500)},
            timeout=10,
        )
        r.raise_for_status()
        data = r.json()
        if isinstance(data, dict):
            data = data.get("data", data.get("markets", []))
        return data if isinstance(data, list) else []

    def fetch_5m_markets(self):
        """Fetch the recurring crypto 5-minute markets from Gamma events.

        Polymarket groups these markets under series such as
        btc-up-or-down-5m. The nested event.market records contain the
        outcomes and CLOB token IDs we need for order-book scanning.
        """
        all_markets = []
        for coin in self.coins:
            series_slug = f"{coin.lower()}-up-or-down-5m"
            r = self.session.get(
                f"{self.gamma_url}/events",
                params={
                    "series_slug": series_slug,
                    "active": "true",
                    "closed": "false",
                    "limit": 100,
                    "order": "endDate",
                    "ascending": "true",
                },
                timeout=10,
            )
            r.raise_for_status()
            events = r.json()
            if isinstance(events, dict):
                events = events.get("data", events.get("events", []))
            if not isinstance(events, list):
                continue

            for event in events:
                for market in event.get("markets") or []:
                    # Attach event metadata so the rest of the scanner can
                    # treat nested markets like normal market records.
                    m = dict(market)
                    if not m.get("eventSlug"):
                        m["eventSlug"] = event.get("slug", "")
                    if not m.get("eventTitle"):
                        m["eventTitle"] = event.get("title", "")
                    all_markets.append(m)
        return all_markets

    def find_5m_crypto_markets(self):
        now = datetime.now(timezone.utc)
        result = []

        try:
            source_markets = self.fetch_5m_markets()
        except Exception as e:
            print(f"market discovery error: {e}")
            return result

        seen = set()
        for m in source_markets:
            slug = str(m.get("slug") or m.get("eventSlug") or "")
            # Exact recurring 5-minute slug pattern, e.g.
            # btc-updown-5m-1791167100. This prevents accidentally
            # accepting 15m/1h markets.
            slug_match = re.match(r"^(btc|eth|xrp|doge|sol)-updown-5m-\d{10}$", slug.lower())
            if not slug_match:
                continue

            coin = slug_match.group(1).upper()
            if coin not in self.coins:
                continue

            outcomes = parse_jsonish(m.get("outcomes"))
            token_ids = parse_jsonish(
                m.get("clobTokenIds") or m.get("clob_token_ids") or m.get("tokens")
            )
            if not isinstance(outcomes, list) or len(outcomes) < 2:
                continue
            if not isinstance(token_ids, list) or len(token_ids) < 2:
                continue

            # These markets have Up/Down outcomes. Use the outcome names
            # instead of assuming token ordering, while retaining a safe
            # fallback to indices 0/1.
            normalized = [str(x).strip().lower() for x in outcomes]
            up_idx = next((i for i, x in enumerate(normalized) if x == "up"), 0)
            down_idx = next((i for i, x in enumerate(normalized) if x == "down"), 1)
            if up_idx >= len(token_ids) or down_idx >= len(token_ids):
                continue

            end = to_dt(m.get("endDate") or m.get("end_date") or m.get("endTime"))
            if not end:
                continue

            seconds_left = (end - now).total_seconds()
            # Include the currently open window and a small grace period
            # around the boundary so polling does not miss a round.
            if not (-30 <= seconds_left <= 420):
                continue

            market_id = str(m.get("id") or m.get("conditionId") or m.get("condition_id") or "")
            unique_key = market_id or slug
            if unique_key in seen:
                continue
            seen.add(unique_key)

            result.append({
                "id": unique_key,
                "question": str(m.get("question") or m.get("title") or ""),
                "slug": slug,
                "coin": coin,
                "end": end,
                "seconds_left": seconds_left,
                "yes_token": str(token_ids[up_idx]),
                "no_token": str(token_ids[down_idx]),
                "raw": m,
            })

        result.sort(key=lambda x: x["end"])
        return result

    def get_book(self, token_id: str):
        r = self.session.get(
            f"{self.clob_url}/book",
            params={"token_id": token_id},
            timeout=5,
        )
        r.raise_for_status()
        return r.json()

    @staticmethod
    def best_ask(book):
        asks = book.get("asks") or []
        prices = []
        for x in asks:
            try:
                prices.append(float(x["price"]))
            except Exception:
                pass
        return min(prices) if prices else None

    @staticmethod
    def ask_size_at(book, price):
        total = 0.0
        for x in book.get("asks") or []:
            try:
                if abs(float(x["price"]) - price) < 1e-9:
                    total += float(x["size"])
            except Exception:
                pass
        return total

    def quote_pair(self, market):
        yes_book = self.get_book(market["yes_token"])
        no_book = self.get_book(market["no_token"])
        yes_ask = self.best_ask(yes_book)
        no_ask = self.best_ask(no_book)
        if yes_ask is None or no_ask is None:
            return None
        return {
            **market,
            "yes_ask": yes_ask,
            "no_ask": no_ask,
            "yes_ask_size": self.ask_size_at(yes_book, yes_ask),
            "no_ask_size": self.ask_size_at(no_book, no_ask),
            "pair_cost": yes_ask + no_ask,
            "timestamp": time.time(),
        }
