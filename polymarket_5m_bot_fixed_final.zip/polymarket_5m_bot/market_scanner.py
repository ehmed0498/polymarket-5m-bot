from __future__ import annotations
import json
import re
import time
from datetime import datetime, timezone
from typing import Any
import requests

def parse_jsonish(value: Any) -> Any:
    if isinstance(value, (list, dict)):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return value
    return value

def to_dt(value: Any):
    if not value:
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    s = str(value).strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
        return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).astimezone(timezone.utc)
    except Exception:
        return None

class MarketScanner:
    def __init__(self, gamma_url: str, clob_url: str, coins: tuple[str, ...]):
        self.gamma_url = gamma_url.rstrip("/")
        self.clob_url = clob_url.rstrip("/")
        self.coins = tuple(c.upper() for c in coins)
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "polymarket-5m-paper-bot/2.0"})

    def _get_json(self, url: str, params=None, timeout=10):
        r = self.session.get(url, params=params, timeout=timeout)
        r.raise_for_status()
        return r.json()

    def fetch_events(self, limit=100):
        data = self._get_json(
            f"{self.gamma_url}/events",
            params={"active": "true", "closed": "false", "limit": limit, "order": "id", "ascending": "false"},
            timeout=10,
        )
        if isinstance(data, dict):
            data = data.get("data", data.get("events", []))
        return data if isinstance(data, list) else []

    def fetch_event_by_slug(self, slug: str):
        try:
            data = self._get_json(f"{self.gamma_url}/events/slug/{slug}", timeout=8)
            return data if isinstance(data, dict) else None
        except requests.RequestException:
            return None

    def _is_5m_crypto(self, event: dict) -> bool:
        slug = str(event.get("slug", "")).lower()
        text = " ".join(str(event.get(k, "")) for k in ("title", "question", "description", "slug")).lower()
        return bool(re.search(r"(?:updown|up-or-down)-5m-\d+$", slug)) or ("5m" in text and ("up or down" in text or "up/down" in text))

    def _coin_for(self, event: dict, market: dict | None = None):
        text = " ".join(str((event or {}).get(k, "")) for k in ("title", "question", "description", "slug"))
        if market:
            text += " " + " ".join(str(market.get(k, "")) for k in ("title", "question", "description", "slug"))
        upper = text.upper()
        for c in self.coins:
            if re.search(rf"\b{re.escape(c)}\b", upper) or f"{c.lower()}-updown-5m-" in text.lower() or f"{c.lower()}-up-or-down-5m-" in text.lower():
                return c
        return None

    def _market_to_record(self, event: dict, m: dict, now: datetime):
        coin = self._coin_for(event, m)
        if not coin:
            return None
        outcomes = parse_jsonish(m.get("outcomes"))
        token_ids = parse_jsonish(m.get("clobTokenIds") or m.get("clob_token_ids") or m.get("tokens"))
        if isinstance(token_ids, dict):
            token_ids = token_ids.get("clobTokenIds") or token_ids.get("tokens")
        if not isinstance(outcomes, list) or len(outcomes) < 2 or not isinstance(token_ids, list) or len(token_ids) < 2:
            return None
        end = to_dt(m.get("endDate") or m.get("end_date") or m.get("endTime") or event.get("endDate"))
        if not end:
            return None
        seconds_left = (end - now).total_seconds()
        if not (-45 <= seconds_left <= 420):
            return None
        yes_idx = next((i for i, x in enumerate(outcomes) if str(x).strip().lower() in {"yes", "up"}), 0)
        no_idx = next((i for i, x in enumerate(outcomes) if str(x).strip().lower() in {"no", "down"}), 1)
        return {
            "id": str(m.get("id") or m.get("conditionId") or m.get("condition_id") or ""),
            "question": str(m.get("question") or m.get("title") or event.get("title") or ""),
            "slug": str(m.get("slug") or event.get("slug") or ""),
            "coin": coin,
            "end": end,
            "seconds_left": seconds_left,
            "yes_token": str(token_ids[yes_idx]),
            "no_token": str(token_ids[no_idx]),
            "raw": m,
        }

    def find_5m_crypto_markets(self):
        now = datetime.now(timezone.utc)
        events = []
        seen = set()
        # Primary discovery: recent active events. 5-minute crypto markets are events containing one or more markets.
        try:
            for event in self.fetch_events():
                slug = str(event.get("slug", ""))
                if slug and slug not in seen and self._is_5m_crypto(event):
                    events.append(event); seen.add(slug)
        except requests.RequestException as e:
            print(f"market discovery warning: events API: {e}")

        # Fallback: query the exact current/adjacent 5-minute slugs.
        window = int(now.timestamp()) // 300 * 300
        for offset in (-600, -300, 0, 300, 600):
            ts = window + offset
            for pattern in ("{coin}-updown-5m-{ts}", "{coin}-up-or-down-5m-{ts}"):
                for coin in self.coins:
                    slug = pattern.format(coin=coin.lower(), ts=ts)
                    if slug in seen:
                        continue
                    event = self.fetch_event_by_slug(slug)
                    if event and self._is_5m_crypto(event):
                        events.append(event); seen.add(slug)

        result = []
        seen_markets = set()
        for event in events:
            markets = event.get("markets") or []
            if isinstance(markets, str):
                markets = parse_jsonish(markets)
            if not isinstance(markets, list):
                markets = []
            # Some responses may represent the event itself as a single market-like object.
            if not markets and (event.get("clobTokenIds") or event.get("tokens")):
                markets = [event]
            for m in markets:
                if not isinstance(m, dict):
                    continue
                rec = self._market_to_record(event, m, now)
                if rec and rec["id"] not in seen_markets:
                    result.append(rec); seen_markets.add(rec["id"])
        return result

    def get_book(self, token_id: str):
        r = self.session.get(f"{self.clob_url}/book", params={"token_id": token_id}, timeout=5)
        r.raise_for_status()
        return r.json()

    @staticmethod
    def best_ask(book):
        asks = book.get("asks") or []
        prices = []
        for x in asks:
            try: prices.append(float(x["price"]))
            except Exception: pass
        return min(prices) if prices else None

    @staticmethod
    def ask_size_at(book, price):
        total = 0.0
        for x in book.get("asks") or []:
            try:
                if abs(float(x["price"]) - price) < 1e-9:
                    total += float(x["size"])
            except Exception: pass
        return total

    def quote_pair(self, market):
        yes_book = self.get_book(market["yes_token"])
        no_book = self.get_book(market["no_token"])
        yes_ask = self.best_ask(yes_book)
        no_ask = self.best_ask(no_book)
        if yes_ask is None or no_ask is None:
            return None
        return {**market, "yes_ask": yes_ask, "no_ask": no_ask, "yes_ask_size": self.ask_size_at(yes_book, yes_ask), "no_ask_size": self.ask_size_at(no_book, no_ask), "pair_cost": yes_ask + no_ask, "timestamp": time.time()}
