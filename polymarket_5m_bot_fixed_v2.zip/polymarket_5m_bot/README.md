# Polymarket 5-Minute Crypto Arbitrage Bot

Safety-first Python bot modeled on the screenshot:

- BTC, ETH, XRP, DOGE, SOL
- ~5-minute binary markets
- 5% of current balance per trade
- Compounding
- Paper trading ON by default
- Order-book YES+NO arbitrage scanner
- Live trading intentionally disabled

## Important
This is not a guaranteed-profit system. It looks for:

    YES best ask + NO best ask + estimated costs < 1

Real fills can differ because of latency, partial fills, fees, liquidity and changing order books.

## Install

Python 3.11+:

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
```

Windows activation:
```text
.venv\Scripts\activate
```

## Run paper bot

```bash
python main.py
```

## Run dashboard

```bash
streamlit run dashboard.py
```

## Main settings

- STARTING_BALANCE=100
- ALLOCATION_PCT=0.05
- MIN_EDGE_PCT=0.50
- ESTIMATED_FEE_PCT=0
- ESTIMATED_SLIPPAGE_PCT=0.10
- POLL_SECONDS=2
- MAX_DAILY_LOSS_PCT=10
- LIVE_TRADING=false

## Strategy

For a binary market, if the cheapest displayed YES and NO asks together cost less than $1, buying both can create a gross spread:

    gross edge = 1 - YES ask - NO ask

The bot subtracts estimated costs and only accepts an opportunity above MIN_EDGE_PCT.

The total budget is:

    current balance × 5%

The project checks displayed liquidity on both legs before simulating the fill.

## Why this does not blindly copy the screenshot

The screenshot says "5-Minute Candle Arbitrage", but it does not reveal the exact entry formula. True arbitrage is different from predicting whether the next candle goes up or down.

This first build implements a measurable order-book arbitrage condition. If your intended strategy uses Binance/Bybit price feeds or a candle-direction signal, the signal engine should be changed rather than guessed.

## Live trading

The current official Polymarket Python SDK is `polymarket-client`. Polymarket's older py-clob-client repository is archived; the new unified SDK is recommended for new projects.

Before live execution, verify:
1. exact market-selection logic,
2. fees and minimum sizes,
3. wallet type and permissions,
4. token allowances,
5. simultaneous/partial fill handling,
6. cancellation and reconciliation,
7. daily loss and kill-switch behavior.

Do not put a private key in source code. Use environment/secret storage.

References:
- https://github.com/Polymarket/py-sdk
- https://github.com/Polymarket/py-clob-client-v2
