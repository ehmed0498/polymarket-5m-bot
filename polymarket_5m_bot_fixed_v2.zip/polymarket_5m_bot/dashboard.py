from pathlib import Path
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Polymarket 5-Coin Audit", layout="centered")
st.title("Polymarket 5-Coin Audit")
st.caption("5-Minute Candle Arbitrage • Paper Trading")

path = Path("trades.csv")
if not path.exists():
    st.info("No paper trades yet. Start with: python main.py")
    st.stop()

df = pd.read_csv(path)
if df.empty:
    st.info("No trades recorded yet.")
    st.stop()

starting = 100.0
balance = float(df.iloc[-1]["balance"])
profit = balance - starting
return_pct = profit / starting * 100

c1, c2 = st.columns(2)
c1.metric("Current Balance", f"${balance:,.2f}", f"{return_pct:+.2f}%")
c2.metric("Total Net Profit", f"${profit:,.2f}")

c3, c4 = st.columns(2)
c3.metric("Trades Executed", len(df))
c4.metric("Current Allocation (5%)", f"${balance*0.05:,.2f}/trade")

st.subheader("Road to $250")
st.progress(min(balance/250, 1.0))
st.write(f"{min(balance/250*100, 100):.1f}%")

st.subheader("Recent Trades")
st.dataframe(df.tail(25), use_container_width=True)

st.subheader("Balance")
chart = df[["timestamp","balance"]].copy()
chart["timestamp"] = pd.to_datetime(chart["timestamp"])
chart = chart.set_index("timestamp")
st.line_chart(chart["balance"])
