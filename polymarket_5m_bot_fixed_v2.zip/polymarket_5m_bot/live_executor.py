class LiveTradingDisabled(Exception):
    pass

class LiveExecutor:
    def __init__(self, enabled=False):
        self.enabled = enabled

    def execute(self, *args, **kwargs):
        if not self.enabled:
            raise LiveTradingDisabled(
                "Live trading is disabled. Paper-test first."
            )
        raise NotImplementedError(
            "Live execution is intentionally gated. Wire the current "
            "polymarket-client SDK here only after validating the wallet, "
            "market type, fees, allowances and order/cancellation flow."
        )
