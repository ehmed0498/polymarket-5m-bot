from __future__ import annotations
import csv
import os
from datetime import datetime, timezone

class PaperEngine:
    def __init__(self, starting_balance: float, csv_path="trades.csv"):
        self.balance = starting_balance
        self.starting_balance = starting_balance
        self.csv_path = csv_path
        self._ensure_csv()

    def _ensure_csv(self):
        if os.path.exists(self.csv_path):
            return
        with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow([
                "timestamp","coin","market_id","question","budget",
                "yes_price","no_price","pair_cost","gross_edge_pct",
                "net_edge_pct","profit","balance"
            ])

    def execute(self, opp):
        cost = opp.budget
        gross_profit = opp.max_pair_count * (1.0 - opp.pair_cost)
        self.balance += gross_profit
        row = [
            datetime.now(timezone.utc).isoformat(),
            opp.coin, opp.market_id, opp.question, round(cost, 6),
            opp.yes_price, opp.no_price, opp.pair_cost,
            opp.gross_edge_pct, opp.net_edge_pct,
            round(gross_profit, 6), round(self.balance, 6)
        ]
        with open(self.csv_path, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(row)
        return {"profit": gross_profit, "balance": self.balance, "pairs": opp.max_pair_count}

    @property
    def return_pct(self):
        return (self.balance / self.starting_balance - 1) * 100
