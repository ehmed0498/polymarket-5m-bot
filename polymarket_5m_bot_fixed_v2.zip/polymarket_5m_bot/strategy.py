from dataclasses import dataclass

@dataclass
class Opportunity:
    market_id: str
    coin: str
    question: str
    yes_price: float
    no_price: float
    pair_cost: float
    gross_edge_pct: float
    estimated_cost_pct: float
    net_edge_pct: float
    max_pair_count: float
    budget: float

class ArbitrageStrategy:
    def __init__(self, allocation_pct=0.05, min_edge_pct=0.50, estimated_fee_pct=0.0, estimated_slippage_pct=0.10):
        self.allocation_pct = allocation_pct
        self.min_edge_pct = min_edge_pct
        self.estimated_cost_pct = estimated_fee_pct + estimated_slippage_pct

    def evaluate(self, quote, balance):
        pair_cost = quote["pair_cost"]
        gross_edge_pct = (1.0 - pair_cost) * 100.0
        net_edge_pct = gross_edge_pct - self.estimated_cost_pct
        budget = balance * self.allocation_pct

        if pair_cost <= 0 or net_edge_pct < self.min_edge_pct:
            return None

        available_pairs = min(quote.get("yes_ask_size", 0.0), quote.get("no_ask_size", 0.0))
        if available_pairs <= 0:
            return None

        max_pair_count = min(budget / pair_cost, available_pairs)
        if max_pair_count <= 0:
            return None

        return Opportunity(
            market_id=quote["id"],
            coin=quote["coin"],
            question=quote["question"],
            yes_price=quote["yes_ask"],
            no_price=quote["no_ask"],
            pair_cost=pair_cost,
            gross_edge_pct=gross_edge_pct,
            estimated_cost_pct=self.estimated_cost_pct,
            net_edge_pct=net_edge_pct,
            max_pair_count=max_pair_count,
            budget=max_pair_count * pair_cost,
        )
