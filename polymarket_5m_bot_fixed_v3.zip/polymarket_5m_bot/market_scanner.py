from __future__ import annotations
import json
import re
import time
from datetime import datetime, timezone
from typing import Any
import requests

def parse_jsonish(value: Any) -> Any:
    if isinstance(value, (list, dict)):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return value
    return value

def to_dt(value: Any):
    if not value:
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    s = str(value).strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
        return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).astimezone(timezone.utc)
    except Exception:
        return None

class MarketScanner:
    def __init__(self, gamma_url: str, clob_url: str, coins: tuple[str, ...]):
        self.gamma_url = gamma_url.rstrip("/")
        self.clob_url = clob_url.rstrip("/")
        self.coins = tuple(c.upper() for c in coins)
        self.session = requests.Session()
        self.session.headers.update({"User-Agent": "polymarket-5m-paper-bot/2.0"})

    def _get_json(self, url: str, params=None, timeout=10):
        r = self.session.get(url, params=params, timeout=timeout)
        r.raise_for_status()
        return r.json()

    def fetch_events(self, limit=100):
        data = self._get_json(
            f"{self.gamma_url}/events",
            params={"active": "true", "closed": "false", "limit": limit, "order": "id", "ascending": "false"},
            timeout=10,
        )
        if isinstance(data, dict):
            data = data.get("data", data.get("events", []))
        return data if isinstance(data, list) else []

    def fetch_event_by_slug(self, slug: str):
        """Fetch the 5-minute event by its public event slug and return its market."""
        try:
            data = self._get_json(f"{self.gamma_url}/events/slug/{slug}", timeout=8)
        except requests.RequestException:
            return None

        if not isinstance(data, dict):
            return None

        markets = data.get("markets") or []
        if isinstance(markets, str):
            markets = parse_jsonish(markets)
        if not isinstance(markets, list):
            markets = []

        # Normally the event contains exactly one binary Up/Down market.
        # Prefer the market with CLOB token IDs and matching 5m question/slug.
        candidates = [m for m in markets if isinstance(m, dict)]
        for m in candidates:
            tokens = parse_jsonish(m.get("clobTokenIds") or m.get("clob_token_ids") or m.get("tokens"))
            outcomes = parse_jsonish(m.get("outcomes"))
            if isinstance(tokens, list) and len(tokens) >= 2 and isinstance(outcomes, list) and len(outcomes) >= 2:
                return m
        return candidates[0] if candidates else None

    def fetch_market_by_slug(self, slug: str):
        """Fetch the market contained in the public 5-minute event slug."""
        m = self.fetch_event_by_slug(slug)
        if m:
            return m

        # Compatibility fallback: Gamma also exposes a market-by-slug endpoint.
        try:
            data = self._get_json(f"{self.gamma_url}/markets/slug/{slug}", timeout=8)
            return data if isinstance(data, dict) else None
        except requests.RequestException:
            pass
        return None

    def _market_to_record(self, m: dict, now: datetime, coin: str, slug: str):
        outcomes = parse_jsonish(m.get("outcomes"))
        token_ids = parse_jsonish(m.get("clobTokenIds") or m.get("clob_token_ids") or m.get("tokens"))
        if isinstance(token_ids, dict):
            token_ids = token_ids.get("clobTokenIds") or token_ids.get("tokens")
        if not isinstance(outcomes, list) or len(outcomes) < 2 or not isinstance(token_ids, list) or len(token_ids) < 2:
            return None

        # For Up/Down 5m markets the slug timestamp is the true window start.
        # Gamma's generic startDate can be the object's creation time, so do not
        # use it to determine whether the market is currently tradable.
        try:
            start_ts = int(slug.rsplit("-", 1)[1])
            start = datetime.fromtimestamp(start_ts, tz=timezone.utc)
            end = datetime.fromtimestamp(start_ts + 300, tz=timezone.utc)
        except Exception:
            end = to_dt(m.get("endDate") or m.get("end_date") or m.get("endTime"))
            if not end:
                return None

        seconds_left = (end - now).total_seconds()
        if not (-30 <= seconds_left <= 360):
            return None

        yes_idx = next((i for i, x in enumerate(outcomes) if str(x).strip().lower() in {"yes", "up"}), 0)
        no_idx = next((i for i, x in enumerate(outcomes) if str(x).strip().lower() in {"no", "down"}), 1)
        return {
            "id": str(m.get("id") or m.get("conditionId") or m.get("condition_id") or slug),
            "question": str(m.get("question") or m.get("title") or slug),
            "slug": str(m.get("slug") or slug),
            "coin": coin,
            "end": end,
            "seconds_left": seconds_left,
            "yes_token": str(token_ids[yes_idx]),
            "no_token": str(token_ids[no_idx]),
            "raw": m,
        }

    def find_5m_crypto_markets(self):
        now = datetime.now(timezone.utc)
        window = int(now.timestamp()) // 300 * 300
        result = []
        seen = set()

        # 5-minute crypto market slugs are deterministic: coin-updown-5m-<window start>.
        # Check the current window and a few adjacent windows so the bot can start
        # cleanly near a 5-minute boundary.
        for coin in self.coins:
            for offset in (-300, 0, 300):
                ts = window + offset
                slug = f"{coin.lower()}-updown-5m-{ts}"
                m = self.fetch_market_by_slug(slug)
                if not m:
                    # A small compatibility fallback for older "up-or-down" slugs.
                    alt_slug = f"{coin.lower()}-up-or-down-5m-{ts}"
                    m = self.fetch_market_by_slug(alt_slug)
                    slug = alt_slug
                if not m:
                    continue
                rec = self._market_to_record(m, now, coin, slug)
                if rec and rec["id"] not in seen:
                    result.append(rec)
                    seen.add(rec["id"])
        return result

    def get_book(self, token_id: str):
        r = self.session.get(f"{self.clob_url}/book", params={"token_id": token_id}, timeout=5)
        r.raise_for_status()
        return r.json()

    @staticmethod
    def best_ask(book):
        asks = book.get("asks") or []
        prices = []
        for x in asks:
            try: prices.append(float(x["price"]))
            except Exception: pass
        return min(prices) if prices else None

    @staticmethod
    def ask_size_at(book, price):
        total = 0.0
        for x in book.get("asks") or []:
            try:
                if abs(float(x["price"]) - price) < 1e-9:
                    total += float(x["size"])
            except Exception: pass
        return total

    def quote_pair(self, market):
        yes_book = self.get_book(market["yes_token"])
        no_book = self.get_book(market["no_token"])
        yes_ask = self.best_ask(yes_book)
        no_ask = self.best_ask(no_book)
        if yes_ask is None or no_ask is None:
            return None
        return {**market, "yes_ask": yes_ask, "no_ask": no_ask, "yes_ask_size": self.ask_size_at(yes_book, yes_ask), "no_ask_size": self.ask_size_at(no_book, no_ask), "pair_cost": yes_ask + no_ask, "timestamp": time.time()}
