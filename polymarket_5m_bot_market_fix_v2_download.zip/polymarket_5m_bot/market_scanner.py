from __future__ import annotations
import json
import re
import time
from datetime import datetime, timezone
from typing import Any
import requests

def parse_jsonish(value: Any) -> Any:
    if isinstance(value, (list, dict)):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return value
    return value

def to_dt(value: Any):
    if not value:
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    s = str(value).strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
        return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).astimezone(timezone.utc)
    except Exception:
        return None

class MarketScanner:
    def __init__(self, gamma_url: str, clob_url: str, coins: tuple[str, ...]):
        self.gamma_url = gamma_url.rstrip("/")
        self.clob_url = clob_url.rstrip("/")
        self.coins = coins
        self.session = requests.Session()
        # Use browser-like headers because the Gamma API may reject the
        # custom/default GitHub Actions User-Agent with HTTP 403.
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/131.0 Safari/537.36"
            ),
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://polymarket.com/",
            "Origin": "https://polymarket.com",
        })

    def fetch_markets(self, limit=100):
        # The generic /markets endpoint can omit the rolling 5-minute
        # crypto markets from its top results. Discover these markets
        # through their recurring series events instead.
        markets = []

        for coin in self.coins:
            series_slug = f"{coin.lower()}-up-or-down-5m"
            r = self.session.get(
                f"{self.gamma_url}/events",
                params={
                    "series_slug": series_slug,
                    "active": "true",
                    "closed": "false",
                    "limit": limit,
                },
                timeout=10,
            )
            r.raise_for_status()
            events = r.json()

            if isinstance(events, dict):
                events = events.get("data", events.get("events", []))
            if not isinstance(events, list):
                continue

            for event in events:
                event_markets = event.get("markets") or []
                if isinstance(event_markets, dict):
                    event_markets = event_markets.get("data", [])
                if not isinstance(event_markets, list):
                    continue

                for market in event_markets:
                    if not isinstance(market, dict):
                        continue

                    # Some responses keep the useful dates on the event.
                    if not market.get("endDate") and event.get("endDate"):
                        market["endDate"] = event["endDate"]
                    if not market.get("startDate") and event.get("startDate"):
                        market["startDate"] = event["startDate"]
                    if not market.get("slug") and event.get("slug"):
                        market["slug"] = event["slug"]
                    if not market.get("question") and event.get("title"):
                        market["question"] = event["title"]

                    markets.append(market)

        # De-duplicate by market id/condition id/slug.
        unique = {}
        for m in markets:
            key = str(
                m.get("id")
                or m.get("conditionId")
                or m.get("condition_id")
                or m.get("slug")
                or id(m)
            )
            unique[key] = m

        return list(unique.values())

    def get_book(self, token_id: str):
        r = self.session.get(
            f"{self.clob_url}/book",
            params={"token_id": token_id},
            timeout=5,
        )
        r.raise_for_status()
        return r.json()

    @staticmethod
    def best_ask(book):
        asks = book.get("asks") or []
        prices = []
        for x in asks:
            try:
                prices.append(float(x["price"]))
            except Exception:
                pass
        return min(prices) if prices else None

    @staticmethod
    def ask_size_at(book, price):
        total = 0.0
        for x in book.get("asks") or []:
            try:
                if abs(float(x["price"]) - price) < 1e-9:
                    total += float(x["size"])
            except Exception:
                pass
        return total

    def quote_pair(self, market):
        yes_book = self.get_book(market["yes_token"])
        no_book = self.get_book(market["no_token"])
        yes_ask = self.best_ask(yes_book)
        no_ask = self.best_ask(no_book)
        if yes_ask is None or no_ask is None:
            return None
        return {
            **market,
            "yes_ask": yes_ask,
            "no_ask": no_ask,
            "yes_ask_size": self.ask_size_at(yes_book, yes_ask),
            "no_ask_size": self.ask_size_at(no_book, no_ask),
            "pair_cost": yes_ask + no_ask,
            "timestamp": time.time(),
        }
