# Polymarket 5-Minute Crypto Arbitrage Bot — V2 Auto-Discovery Paper Audit

This version is for **paper testing only**. Live orders are intentionally disabled.

## What V2 adds
- $100 starting balance by default.\n- Auto-discovers available recurring `*-up-or-down-5m` series from Gamma; configured coin tickers are fallback if the series catalogue is unavailable.
- Configurable allocation (default 5%; use 5%, 10%, or 20% for separate paper runs).
- Net P&L estimate subtracts configured fee/slippage assumptions instead of reporting only gross spread.
- Fresh `trades.csv` ledger per run, including estimated costs and drawdown.
- Graceful runtime limit (default 340 minutes) so the report can be written before the GitHub Actions 350-minute job timeout.
- `paper_report.txt` summary with run time, estimated net P&L, hourly P&L, and clearly labeled 24-hour extrapolation.
- Stops when configured paper loss limit is reached.

## Important limitations
This is not a guaranteed-profit system. The displayed order book can change before a fill; queue position, partial fills, fees, latency and simultaneous-leg execution are not fully modeled. The daily extrapolation is a mathematical projection of a short paper run, **not a forecast or earnings promise**. A $15–$20 daily target on $100 would require 15–20% daily returns and is highly unrealistic to expect consistently.

## Run
Python 3.11+:

```bash
pip install -r requirements.txt
cp .env.example .env
python main.py
```

## Settings (`.env`)
```dotenv
LIVE_TRADING=false
STARTING_BALANCE=100
ALLOCATION_PCT=0.05
MIN_EDGE_PCT=0.50
ESTIMATED_FEE_PCT=0
ESTIMATED_SLIPPAGE_PCT=0.10
POLL_SECONDS=2
BOT_RUNTIME_MINUTES=340
MAX_DAILY_LOSS_PCT=10
REPORT_PATH=paper_report.txt
```

For comparison, run separate paper tests with `ALLOCATION_PCT=0.05`, `0.10`, and `0.20`. Do not infer that higher allocation improves the strategy; it magnifies both profits and losses. Compare results over many runs and market conditions.

## Output
- `trades.csv`: one row per simulated fill
- `paper_report.txt`: final summary

The bot refuses to run if `LIVE_TRADING=true`. No live trading implementation is included.
\n## Auto-discovery note\n\nAuto-discovery is limited to series exposed by Polymarket Gamma matching the `*-up-or-down-5m` naming pattern. API pagination/limits or API changes may mean the scanner does not see every market. Startup logs list discovered series. More markets increase scan coverage, not guaranteed profit. Keep paper mode enabled.\n