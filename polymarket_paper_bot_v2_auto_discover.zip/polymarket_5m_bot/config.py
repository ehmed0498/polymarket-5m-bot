from dataclasses import dataclass
import os
from dotenv import load_dotenv

load_dotenv()

def env_bool(name: str, default: bool) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}

@dataclass(frozen=True)
class Config:
    live_trading: bool = env_bool("LIVE_TRADING", False)
    starting_balance: float = float(os.getenv("STARTING_BALANCE", "100"))
    allocation_pct: float = float(os.getenv("ALLOCATION_PCT", "0.05"))
    min_edge_pct: float = float(os.getenv("MIN_EDGE_PCT", "0.50"))
    estimated_fee_pct: float = float(os.getenv("ESTIMATED_FEE_PCT", "0"))
    estimated_slippage_pct: float = float(os.getenv("ESTIMATED_SLIPPAGE_PCT", "0.10"))
    poll_seconds: float = float(os.getenv("POLL_SECONDS", "2"))
    runtime_minutes: float = float(os.getenv("BOT_RUNTIME_MINUTES", "340"))
    report_path: str = os.getenv("REPORT_PATH", "paper_report.txt")
    max_trades_per_5m: int = int(os.getenv("MAX_TRADES_PER_5M", "5"))
    max_daily_loss_pct: float = float(os.getenv("MAX_DAILY_LOSS_PCT", "10"))
    gamma_url: str = os.getenv("GAMMA_URL", "https://gamma-api.polymarket.com")
    clob_url: str = os.getenv("CLOB_URL", "https://clob.polymarket.com")
    auto_discover_crypto: bool = env_bool("AUTO_DISCOVER_CRYPTO", True)
    coins: tuple[str, ...] = tuple(
        x.strip().upper() for x in os.getenv("COINS", "BTC,ETH,XRP,DOGE,SOL").split(",") if x.strip()
    )
