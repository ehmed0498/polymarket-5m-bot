from pathlib import Path
import pandas as pd
import streamlit as st

st.set_page_config(page_title="Polymarket Paper Audit V2", layout="centered")
st.title("Polymarket Paper Audit V2")
st.caption("Paper simulation only — not a prediction or guarantee of returns")

report_path = Path("paper_report.txt")
if report_path.exists():
    with st.expander("Latest run report", expanded=True):
        st.text(report_path.read_text(encoding="utf-8"))

path = Path("trades.csv")
if not path.exists():
    st.info("No paper trades yet. Start with: python main.py")
    st.stop()

df = pd.read_csv(path)
if df.empty:
    st.info("No paper trades recorded in this run yet.")
    st.stop()

starting = 100.0
try:
    if report_path.exists():
        for line in report_path.read_text(encoding="utf-8").splitlines():
            if line.startswith("Starting balance: $"):
                starting = float(line.split("$", 1)[1])
                break
except Exception:
    pass
balance = float(df.iloc[-1]["balance"])
profit = balance - starting
return_pct = (profit / starting * 100) if starting else 0

c1, c2 = st.columns(2)
c1.metric("Simulated balance", f"${balance:,.2f}", f"{return_pct:+.2f}%")
c2.metric("Estimated net P&L", f"${profit:+,.2f}")
c3, c4 = st.columns(2)
c3.metric("Trades logged", len(df))
c4.metric("Configured allocation", "See run report")

st.subheader("Recent paper trades")
st.dataframe(df.tail(25), use_container_width=True)
st.subheader("Simulated balance")
chart = df[["timestamp", "balance"]].copy()
chart["timestamp"] = pd.to_datetime(chart["timestamp"])
st.line_chart(chart.set_index("timestamp")["balance"])
st.warning("Paper fills and projected daily results may differ substantially from real execution. Do not treat them as expected earnings.")
