from __future__ import annotations
import csv
import signal
import time
from datetime import datetime, timezone
from pathlib import Path
from config import Config
from market_scanner import MarketScanner
from strategy import ArbitrageStrategy
from paper_engine import PaperEngine

_stop_requested = False

def _request_stop(signum, frame):
    global _stop_requested
    _stop_requested = True

def write_report(engine, started, cfg, stop_reason):
    ended = time.time()
    elapsed_seconds = max(ended - started, 1.0)
    profit = engine.balance - engine.starting_balance
    trades = []
    try:
        with open("trades.csv", newline="", encoding="utf-8") as f:
            trades = list(csv.DictReader(f))
    except OSError:
        pass
    wins = sum(1 for r in trades if float(r.get("net_profit") or 0) > 0)
    losses = sum(1 for r in trades if float(r.get("net_profit") or 0) < 0)
    max_dd = max((float(r.get("drawdown_pct") or 0) for r in trades), default=0.0)
    hours = elapsed_seconds / 3600.0
    hourly = profit / hours
    report = [
        "POLYMARKET PAPER BOT — RUN REPORT",
        "=================================",
        f"Start (UTC): {datetime.fromtimestamp(started, timezone.utc).isoformat()}",
        f"End (UTC): {datetime.fromtimestamp(ended, timezone.utc).isoformat()}",
        f"Stop reason: {stop_reason}",
        f"Runtime: {elapsed_seconds/60:.2f} minutes",
        f"Starting balance: ${engine.starting_balance:.4f}",
        f"Ending simulated balance: ${engine.balance:.4f}",
        f"Estimated net P&L: ${profit:+.4f}",
        f"Return: {engine.return_pct:+.3f}%",
        f"Trades logged: {len(trades)} (positive: {wins}, negative: {losses})",
        f"Max observed peak-to-trough drawdown: {max_dd:.3f}%",
        f"Observed P&L per hour: ${hourly:+.4f}",
        f"Simple 24-hour extrapolation (NOT a forecast): ${hourly*24:+.4f}",
        f"Configured allocation: {cfg.allocation_pct*100:.2f}% of balance per opportunity",
        f"Configured minimum net edge: {cfg.min_edge_pct:.3f}%",
        "",
        "IMPORTANT: This is a simplified paper estimate, not verified executable profit.",
        "It cannot fully model queue priority, partial fills, market movement, or actual fees.",
        "Do not treat the 24-hour extrapolation as an earnings expectation.",
    ]
    content = "\n".join(report) + "\n"
    Path(cfg.report_path).write_text(content, encoding="utf-8")
    print("\n" + content)
    print("Trade ledger saved to trades.csv")
    print(f"Run report saved to {cfg.report_path}")

def main():
    global _stop_requested
    cfg = Config()
    if cfg.live_trading:
        print("LIVE_TRADING=true detected.")
        print("This build intentionally refuses to place live orders.")
        print("Set LIVE_TRADING=false for paper testing.")
        return

    signal.signal(signal.SIGTERM, _request_stop)
    signal.signal(signal.SIGINT, _request_stop)
    scanner = MarketScanner(cfg.gamma_url, cfg.clob_url, cfg.coins, cfg.auto_discover_crypto)
    strategy = ArbitrageStrategy(
        cfg.allocation_pct, cfg.min_edge_pct,
        cfg.estimated_fee_pct, cfg.estimated_slippage_pct
    )
    engine = PaperEngine(cfg.starting_balance)
    started = time.time()
    runtime_limit = max(cfg.runtime_minutes, 1.0) * 60
    daily_loss_limit = cfg.starting_balance * cfg.max_daily_loss_pct / 100.0
    stop_reason = "configured runtime reached"

    print("=" * 72)
    print("POLYMARKET 5-MINUTE CRYPTO ARBITRAGE BOT — V2 PAPER AUDIT")
    print("MODE: PAPER ONLY; LIVE ORDERS DISABLED")
    print(f"Starting balance: ${engine.balance:.2f}")
    print(f"Allocation: {cfg.allocation_pct*100:.2f}%")
    print(f"Minimum net edge: {cfg.min_edge_pct:.2f}%")
    print(f"Runtime limit: {cfg.runtime_minutes:.0f} minutes")
    print(f"Estimated daily loss stop: ${daily_loss_limit:.2f}")
    print("=" * 72)

    try:
        while not _stop_requested and time.time() - started < runtime_limit:
            try:
                markets = scanner.find_5m_crypto_markets()
                print(f"\n[{datetime.now(timezone.utc).strftime('%H:%M:%S')} UTC] markets={len(markets)} balance=${engine.balance:.4f}")
                for market in markets:
                    if _stop_requested or time.time() - started >= runtime_limit:
                        break
                    try:
                        quote = scanner.quote_pair(market)
                        if not quote:
                            continue
                        opp = strategy.evaluate(quote, engine.balance)
                        if opp:
                            print(f"EDGE {opp.coin}: YES={opp.yes_price:.4f} NO={opp.no_price:.4f} pair={opp.pair_cost:.4f} net={opp.net_edge_pct:.3f}% budget=${opp.budget:.2f}")
                            result = engine.execute(opp)
                            print(f"  PAPER ESTIMATE: pairs={result['pairs']:.4f} gross=${result['gross_profit']:.4f} estimated_cost=${result['estimated_cost']:.4f} net=${result['profit']:.4f} balance=${result['balance']:.4f}")
                            if engine.balance <= cfg.starting_balance - daily_loss_limit:
                                stop_reason = "configured loss stop reached"
                                _stop_requested = True
                                break
                    except Exception as e:
                        print(f"market error: {e}")
                if not _stop_requested and time.time() - started < runtime_limit:
                    time.sleep(max(cfg.poll_seconds, 0.1))
            except Exception as e:
                print(f"scanner error: {e}")
                time.sleep(max(cfg.poll_seconds, 3))
        if _stop_requested and stop_reason == "configured runtime reached":
            stop_reason = "manual stop or termination signal"
    finally:
        write_report(engine, started, cfg, stop_reason)

if __name__ == "__main__":
    main()
