from __future__ import annotations
import json
import re
import time
from datetime import datetime, timezone, timedelta
from typing import Any
import requests

def parse_jsonish(value: Any) -> Any:
    if isinstance(value, (list, dict)):
        return value
    if isinstance(value, str):
        try:
            return json.loads(value)
        except Exception:
            return value
    return value

def to_dt(value: Any):
    if not value:
        return None
    if isinstance(value, (int, float)):
        return datetime.fromtimestamp(value, tz=timezone.utc)
    s = str(value).strip()
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
        return (dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)).astimezone(timezone.utc)
    except Exception:
        return None

class MarketScanner:
    def __init__(self, gamma_url: str, clob_url: str, coins: tuple[str, ...], auto_discover=True):
        self.gamma_url = gamma_url.rstrip("/")
        self.clob_url = clob_url.rstrip("/")
        self.coins = tuple(c.upper() for c in coins)
        self.auto_discover = auto_discover
        self._series_cache = None
        self.session = requests.Session()
        # Use browser-like headers because the Gamma API may reject the
        # custom/default GitHub Actions User-Agent with HTTP 403.
        self.session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (X11; Linux x86_64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/131.0 Safari/537.36"
            ),
            "Accept": "application/json, text/plain, */*",
            "Referer": "https://polymarket.com/",
            "Origin": "https://polymarket.com",
        })

    def discover_5m_series(self):
        """Discover recurring 5-minute up/down series from Gamma, with configured-coin fallback."""
        if self._series_cache is not None:
            return self._series_cache

        series = {}
        if self.auto_discover:
            try:
                # Gamma's series catalogue allows the scanner to discover new
                # supported crypto series instead of hard-coding only a few coins.
                r = self.session.get(
                    f"{self.gamma_url}/series",
                    params={"limit": 1000},
                    timeout=15,
                )
                r.raise_for_status()
                payload = r.json()
                if isinstance(payload, dict):
                    payload = payload.get("data", payload.get("series", []))
                if isinstance(payload, list):
                    for item in payload:
                        if not isinstance(item, dict):
                            continue
                        slug = str(item.get("slug") or "").strip().lower()
                        if slug.endswith("-up-or-down-5m"):
                            prefix = slug[:-len("-up-or-down-5m")]
                            if prefix:
                                series[slug] = prefix.upper()
            except (requests.RequestException, ValueError, TypeError) as exc:
                print(f"Series auto-discovery unavailable; using configured coins. ({exc})")

        # Always include explicitly configured coin series as a fallback.
        for coin in self.coins:
            slug = f"{coin.lower()}-up-or-down-5m"
            series.setdefault(slug, coin)

        self._series_cache = series
        print(f"5-minute series discovered: {len(series)}")
        if series:
            print("Series symbols: " + ", ".join(series.values()))
        return series

    def fetch_markets(self, limit=100):
        # Discover all available recurring 5-minute up/down crypto series,
        # then fetch their active events. Configured coins remain as fallback.
        markets = []
        series_map = self.discover_5m_series()

        for series_slug, coin_symbol in series_map.items():
            try:
                r = self.session.get(
                    f"{self.gamma_url}/events",
                    params={
                        "series_slug": series_slug,
                        "active": "true",
                        "closed": "false",
                        "limit": limit,
                    },
                    timeout=10,
                )
                r.raise_for_status()
                events = r.json()
            except (requests.RequestException, ValueError) as exc:
                print(f"Skipping series {series_slug}: {exc}")
                continue

            if isinstance(events, dict):
                events = events.get("data", events.get("events", []))
            if not isinstance(events, list):
                continue

            for event in events:
                if not isinstance(event, dict):
                    continue
                event_markets = event.get("markets") or []
                if isinstance(event_markets, dict):
                    event_markets = event_markets.get("data", [])
                if not isinstance(event_markets, list):
                    continue

                for market in event_markets:
                    if not isinstance(market, dict):
                        continue
                    if not market.get("endDate") and event.get("endDate"):
                        market["endDate"] = event["endDate"]
                    if not market.get("startDate") and event.get("startDate"):
                        market["startDate"] = event["startDate"]
                    if not market.get("slug") and event.get("slug"):
                        market["slug"] = event["slug"]
                    if not market.get("question") and event.get("title"):
                        market["question"] = event["title"]
                    market["_discovered_coin"] = coin_symbol
                    markets.append(market)

        unique = {}
        for m in markets:
            key = str(
                m.get("id")
                or m.get("conditionId")
                or m.get("condition_id")
                or m.get("slug")
                or id(m)
            )
            unique[key] = m
        return list(unique.values())

    def find_5m_crypto_markets(self):
        """Return only currently live, active 5-minute crypto markets."""
        raw_markets = self.fetch_markets(limit=100)
        normalized = []
        now = datetime.now(timezone.utc)

        for market in raw_markets:
            if not isinstance(market, dict):
                continue

            # Never query books for closed/inactive/non-tradable markets.
            if market.get("closed") is True or market.get("active") is False:
                continue
            if market.get("acceptingOrders") is False:
                continue

            slug = str(market.get("slug") or "").lower()
            question = str(
                market.get("question")
                or market.get("title")
                or ""
            )
            text = f"{slug} {question}"

            if "5m" not in text and "5-minute" not in text and "5 minute" not in text:
                continue

            coin = str(market.get("_discovered_coin") or "").upper().strip()
            if not coin:
                # Fallback for markets returned without series metadata.
                coin = next((c for c in self.coins if c.lower() in text), None)
            if not coin:
                # Do not infer tickers from arbitrary substrings in question text;
                # only include markets tied to a discovered/configured 5m series.
                continue

            # Normalize dates from the market/event. A rolling 5-minute
            # market is usable only while its current window is open.
            start_dt = to_dt(market.get("startDate") or market.get("start_date"))
            end_dt = to_dt(market.get("endDate") or market.get("end_date"))

            if start_dt and end_dt:
                if not (start_dt <= now < end_dt):
                    continue
            elif end_dt:
                # If only an end is available, don't query already-expired books.
                if now >= end_dt:
                    continue
            elif start_dt:
                # Avoid selecting future windows when the API omits endDate.
                if now < start_dt:
                    continue

            token_ids = market.get("clobTokenIds") or market.get("clob_token_ids")
            if isinstance(token_ids, str):
                try:
                    token_ids = json.loads(token_ids)
                except Exception:
                    token_ids = [x.strip() for x in token_ids.split(",") if x.strip()]
            if isinstance(token_ids, dict):
                token_ids = token_ids.get("data") or token_ids.get("tokens")

            outcomes = market.get("outcomes")
            if isinstance(outcomes, str):
                try:
                    outcomes = json.loads(outcomes)
                except Exception:
                    outcomes = [x.strip() for x in outcomes.split(",") if x.strip()]

            if not isinstance(token_ids, list) or len(token_ids) < 2:
                tokens = market.get("tokens")
                if isinstance(tokens, list):
                    token_ids = [
                        t.get("token_id") or t.get("tokenId") or t.get("id")
                        for t in tokens
                        if isinstance(t, dict)
                    ]
                    token_ids = [x for x in token_ids if x]

            if not isinstance(token_ids, list) or len(token_ids) < 2:
                continue

            yes_idx, no_idx = 0, 1
            if isinstance(outcomes, list) and len(outcomes) >= 2:
                labels = [str(x).strip().lower() for x in outcomes]
                for i, label in enumerate(labels):
                    if label in {"yes", "up"}:
                        yes_idx = i
                    elif label in {"no", "down"}:
                        no_idx = i

            if yes_idx >= len(token_ids) or no_idx >= len(token_ids):
                continue

            m = dict(market)
            m["coin"] = coin
            m["question"] = question or m.get("title") or slug
            m["yes_token"] = str(token_ids[yes_idx])
            m["no_token"] = str(token_ids[no_idx])
            normalized.append(m)

        unique = {}
        for m in normalized:
            key = str(
                m.get("id")
                or m.get("conditionId")
                or m.get("condition_id")
                or m.get("slug")
            )
            unique[key] = m

        return list(unique.values())

    def get_book(self, token_id: str):
        r = self.session.get(
            f"{self.clob_url}/book",
            params={"token_id": token_id},
            timeout=5,
        )
        r.raise_for_status()
        return r.json()

    @staticmethod
    def best_ask(book):
        asks = book.get("asks") or []
        prices = []
        for x in asks:
            try:
                prices.append(float(x["price"]))
            except Exception:
                pass
        return min(prices) if prices else None

    @staticmethod
    def ask_size_at(book, price):
        total = 0.0
        for x in book.get("asks") or []:
            try:
                if abs(float(x["price"]) - price) < 1e-9:
                    total += float(x["size"])
            except Exception:
                pass
        return total

    def quote_pair(self, market):
        try:
            yes_book = self.get_book(market["yes_token"])
            no_book = self.get_book(market["no_token"])
        except requests.HTTPError as exc:
            if exc.response is not None and exc.response.status_code == 404:
                return None
            raise
        yes_ask = self.best_ask(yes_book)
        no_ask = self.best_ask(no_book)
        if yes_ask is None or no_ask is None:
            return None
        return {
            **market,
            "yes_ask": yes_ask,
            "no_ask": no_ask,
            "yes_ask_size": self.ask_size_at(yes_book, yes_ask),
            "no_ask_size": self.ask_size_at(no_book, no_ask),
            "pair_cost": yes_ask + no_ask,
            "timestamp": time.time(),
        }
