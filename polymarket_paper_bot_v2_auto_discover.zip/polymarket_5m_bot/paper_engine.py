from __future__ import annotations
import csv
import os
from datetime import datetime, timezone

FIELDS = [
    "timestamp", "coin", "market_id", "question", "budget",
    "yes_price", "no_price", "pair_cost", "gross_edge_pct",
    "estimated_cost_pct", "net_edge_pct", "pairs", "gross_profit",
    "estimated_cost", "net_profit", "balance", "drawdown_pct"
]

class PaperEngine:
    """Paper ledger. Net P&L is estimated, not a promise of executable fills."""
    def __init__(self, starting_balance: float, csv_path="trades.csv"):
        self.balance = float(starting_balance)
        self.starting_balance = float(starting_balance)
        self.peak_balance = float(starting_balance)
        self.csv_path = csv_path
        self.trade_count = 0
        self._ensure_csv()

    def _ensure_csv(self):
        # Start a fresh ledger for each workflow run so the final report reflects
        # only this run, rather than appending to stale results from a prior run.
        with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(FIELDS)

    def execute(self, opp):
        budget = float(opp.budget)
        gross_profit = float(opp.max_pair_count) * (1.0 - float(opp.pair_cost))
        estimated_cost = budget * (float(opp.estimated_cost_pct) / 100.0)
        # Do not let a negative estimated net result increase the paper balance.
        net_profit = gross_profit - estimated_cost
        self.balance += net_profit
        self.peak_balance = max(self.peak_balance, self.balance)
        drawdown_pct = ((self.peak_balance - self.balance) / self.peak_balance * 100.0) if self.peak_balance else 0.0
        self.trade_count += 1
        row = [
            datetime.now(timezone.utc).isoformat(), opp.coin, opp.market_id,
            opp.question, round(budget, 6), round(opp.yes_price, 6),
            round(opp.no_price, 6), round(opp.pair_cost, 6),
            round(opp.gross_edge_pct, 6), round(opp.estimated_cost_pct, 6),
            round(opp.net_edge_pct, 6), round(opp.max_pair_count, 6),
            round(gross_profit, 6), round(estimated_cost, 6),
            round(net_profit, 6), round(self.balance, 6), round(drawdown_pct, 6)
        ]
        with open(self.csv_path, "a", newline="", encoding="utf-8") as f:
            csv.writer(f).writerow(row)
        return {
            "profit": net_profit, "gross_profit": gross_profit,
            "estimated_cost": estimated_cost, "balance": self.balance,
            "pairs": opp.max_pair_count, "drawdown_pct": drawdown_pct,
        }

    @property
    def return_pct(self):
        return (self.balance / self.starting_balance - 1) * 100 if self.starting_balance else 0.0
